from setuptools import setup

setup(
	name="my_validator",
	packages=["my_validator"],
	version="0.0.1",
	description="Libreria de validación de datos",
	author="Jesus Zerpa",
	author_email="jesus26abraham1996@gmail.com",
	url="https://zerpatechnology.com/projects/easy_validator",
	keywords=["easy validator","flask","quart"],
	scripts=[],
	entry_points={

	}
	)